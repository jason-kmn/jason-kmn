# SXM_App
 Implementation of the Smart eXchange Market (SXM App) in the context of Information Systems Applications Development course in AUEB
