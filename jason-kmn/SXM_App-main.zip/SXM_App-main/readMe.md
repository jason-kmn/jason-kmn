Η εφαρμογή μπορεί να τρέξει μέσω android studio.
Για να γίνει αυτο θα πρέπει να ορίσετε στο αρχείο local.properties το sdk του Android που αντιστοιχεί στον υπολογιστή σας.
    π.χ. sdk.dir=C\:\\Users\\user\\AppData\\Local\\Android\\Sdk
